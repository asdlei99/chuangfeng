<?php
/**
 * Created by PhpStorm.
 * User: Venice
 * Date: 2019/5/30
 * Time: 10:53
 */
namespace app\lib\enum;

class ScopeEnum
{
    const User = 16;
    const Super = 32;
}